package com.niit.onlineshopbackend;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.onlineshop.DAO.UserDAO;
import com.niit.onlineshop.model.Category;
import com.niit.onlineshop.model.User;

public class UserTestCase {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		UserDAO userDAO =(UserDAO) context.getBean("UserDAO");
		User user=(User) context.getBean("user");
		user.setId("u_02");
		user.setContact("9441904132");
		user.setMail("gvvineeth@gmail.com");
		user.setName("vineeth");
		user.setPassword("vineeth@123");
		user.setRole("user");
		System.out.println(userDAO.save(user));
		System.out.println("data inserted in db....");
	
		
		userDAO.update(user);
		
	userDAO.delete(user);
	List<User> ulist=userDAO.list();
	for(User u:ulist)
	{
		System.out.println("User name:"+u.getName());
		System.out.println("User ID:"+u.getId());
	}
	}
}
