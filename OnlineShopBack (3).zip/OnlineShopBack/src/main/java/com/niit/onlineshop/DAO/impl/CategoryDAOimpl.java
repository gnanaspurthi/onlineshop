package com.niit.onlineshop.DAO.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateExceptionTranslator;
import org.springframework.orm.hibernate5.HibernateJdbcException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

import javax.management.Query;

import com.niit.onlineshop.DAO.CategoryDAO;
import com.niit.onlineshop.model.Category;

@Repository("categoryDAO")
public class CategoryDAOimpl<SessionFactory> implements CategoryDAO {
	@Autowired
	SessionFactory sessionFactory;
 
	public CategoryDAOimpl(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}
	
@Transactional
	public boolean save(Category category) {
	try {
		{
			if(get(category.getId())!=null)
			{
				return false;
			}
		}
		sessionFactory.getopenSession().save(category);
		return true;
		
	} catch (Exception e) {
		
		e.printStackTrace();
	}
	
			return false;
	}
@Transactional
	public boolean update(Category category) {
		try {
			if(get(category.getId())==null)
			{
				return false;
			}
			sessionFactory.getopenSession().update(category);
			return true;
			
		} catch (Exception e) {
		
			e.printStackTrace();
		return false;
	}
}
    @Transactional
	public Category get(String id) {
    	return(Category)sessionFactory.opensession().get(Category.class,id);
		
	}

	public boolean delete(Category category) {
		try {
			if(get(category.getId())==null)
			{
				return false;
			}
			sessionFactory.getopenSession().delete(category);
			return true;
		} catch (Exception e) {
		
			e.printStackTrace();
		
				return false;
	}
	}
	public List<Category> List() {
		String hql="from category";
		Query query=sessionFactory.openSession().createQuery(hql);
		return query.list();
	
}
	}