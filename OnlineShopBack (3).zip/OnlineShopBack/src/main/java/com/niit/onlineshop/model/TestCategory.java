package com.niit.onlineshop.model;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestCategory {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.onlineshop.model");
		context.refresh();
		context.getBean("Category");
		System.out.println("created successfully");
		

	}

}
