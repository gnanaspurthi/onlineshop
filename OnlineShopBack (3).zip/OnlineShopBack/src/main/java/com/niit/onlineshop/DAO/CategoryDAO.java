package com.niit.onlineshop.DAO;

import com.niit.onlineshop.model.Category;

import java.util.List;

public interface CategoryDAO {
	
	
public boolean save(Category category);
public boolean update(Category category);
public Category get(String id);
public boolean delete(Category category);
public List<Category> List();
}
