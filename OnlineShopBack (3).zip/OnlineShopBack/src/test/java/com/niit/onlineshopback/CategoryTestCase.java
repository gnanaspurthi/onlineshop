package com.niit.onlineshopback;

import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.onlineshop.DAO.CategoryDAO;
import com.niit.onlineshop.model.Category;


public class CategoryTestCase {
	@Autowired
	AnnotationConfigApplicationContext context;
	@Autowired
	Category category;
	@Autowired
	CategoryDAO categoryDAO;
	public void init()
	{
		context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.onlineshop");
		context.refresh();
		categoryDAO=(CategoryDAO) context.getBean("categoryDAO");
		category=(Category) context.getBean("category");
		}
	public void createCategoryTestCase()
	{
		category.setId("cat_04");
		category.setName("footwear");
		category.setDescription("wedges,floats");
		Boolean status= categoryDAO.save(category);
		Assert.assertEquals("Create Category Test Case",true,status);
		
	}

}
