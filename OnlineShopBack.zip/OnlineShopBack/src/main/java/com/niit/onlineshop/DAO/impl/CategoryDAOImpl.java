package com.niit.onlineshop.DAO.impl;

import java.util.Locale.Category;

import com.niit.onlineshop.DAO.CategoryDAO;

public class CategoryDAOImpl implements CategoryDAO {

	public boolean save(Category category) {
		
		return false;
	}

	public boolean update(Category category) {
		
		return false;
	}

	public Category get(String id) {
	
		return null;
	}

	public boolean delete(Category category) {
		
		return false;
	}

	public java.util.List<Category> List() {
	
		return null;
	}

	
	
	
}
