package com.niit.onlineshop.model;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class testcategory {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		AnnotationConfigApplicationContext Context=new AnnotationConfigApplicationContext();
		Context.scan("com.niit.onlineshop.model");
	    Context.refresh();
	    Context.getBean("category");
	    System.out.println("category instance is created successfully");
	    
	}

}
