package com.niit.onlineshopbackend;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.onlineshop.DAO.ProductDAO;
import com.niit.onlineshop.model.Category;
import com.niit.onlineshop.model.Product;

public class ProductTestCase {

	public static void main(String[] args) {
	
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");
		Product product=(Product) context.getBean("product");
		 product.setId("pro_02");
		 product.setName("laptop");
		 product.setPrice(52000);
         product.setSupplier_id("sup_02");	
         product.setCategory_id("cat_01");
         product.setId("pro_01");
		 product.setName("accessories");
		 product.setPrice(2000);
         product.setSupplier_id("sup_03");	
         product.setCategory_id("cat_02");

		System.out.println(productDAO.save(product));
		 System.out.println("data inserted into db....");
		productDAO.update(product);
				
		System.out.println("data updated..........");
		
		 productDAO.delete(product);

         System.out.println("data deleted in db....");
		 List<Product> plist=productDAO.list();
			for(Product p:plist)
			{
				System.out.println("product name:"+p.getName());
				System.out.println("product ID:"+p.getId());
				System.out.println("product price:"+p.getPrice());
				System.out.println("product supplierid:"+p.getSupplier_id());
				System.out.println("product category id:"+p.getCategory_id());
				
			}

	}

}
