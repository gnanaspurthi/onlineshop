package com.niit.onlineshopbackend;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.onlineshop.DAO.CategoryDAO;
import com.niit.onlineshop.model.Category;


public class CategoryTestCase {
	
static AnnotationConfigApplicationContext context;
	@Autowired
	static Category category;
	@Autowired
	static CategoryDAO categoryDAO;
	@Before
	public  void init()
	{
	 context=new AnnotationConfigApplicationContext();
	context.scan("com.niit");
	 context.refresh();
 categoryDAO =(CategoryDAO) context.getBean("categoryDAO");
	 category=(Category) context.getBean("category");
	}
	@Test
	public void CreateCategoryTestCase()
	{
		category.setId("cat_07");
		category.setName("Footwe");
		category.setDescription("flats");
	
	Assert.assertEquals("Create Category Test Case",true,categoryDAO.save(category));
	}
	@Test
	public void updateCategoryTestCase()
	{
		category.setId("cat_07");
		category.setName("Footwear");
		category.setDescription("kidsshoes");
		Assert.assertEquals("update Category Test Case",true,categoryDAO.update(category));
	
	}
	@Test
	public void deleteCategoryTestCase()
	{
		category.setId("cat_07");
		
		Assert.assertEquals("update Category Test Case",true,categoryDAO.delete(category));
	
	}
	@Test
	public void getCategoryTestCase()
	{
		Assert.assertEquals("get Category Test Case",null,categoryDAO.get("id"));
		
		
	}
	@Test
	public void getAllCategoryTestCase()
	{
		Assert.assertEquals("update Category Test Case",true,categoryDAO.get("id"));

	}
	}