package com.niit.onlineshopbackend;
import java.util.List;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.niit.onlineshop.DAO.SupplierDAO;
import com.niit.onlineshop.model.Supplier;
public class SupplierTestCase {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		SupplierDAO supplierDAO = (SupplierDAO) context.getBean("SupplierDAO");
		Supplier supplier=(Supplier) context.getBean("supplier");
 //save function
		supplier.setId("sup_05");
   supplier.setName("nanima");
   supplier.setAddress("gandhiroad");
   System.out.println(supplierDAO.save(supplier));
 System.out.println("data inserted into db....");
//update function	
 //supplierDAO.update(supplier);System.out.println("data updated..........");
	//delete function
	 //supplierDAO.delete(supplier); System.out.println("data deleted in db....");
	//list function
   
   List<Supplier> slist=supplierDAO.list();for(Supplier s:slist)
		{
			System.out.println("product name:"+s.getName());
			System.out.println("product ID:"+s.getId());
			System.out.println("product price:"+s.getAddress());
			
			}
}
}